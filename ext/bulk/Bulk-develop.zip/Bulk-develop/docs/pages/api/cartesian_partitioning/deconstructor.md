# `bulk::cartesian_partitioning::~cartesian_partitioning`

```cpp
virtual ~cartesian_partitioning() = default;
```

Virtual deconstructor.
