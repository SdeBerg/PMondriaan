# `bulk::var::world`

```cpp
bulk::world& world();
```

Returns a reference to the world the variable belongs to

## Return value

- A reference to the world.
