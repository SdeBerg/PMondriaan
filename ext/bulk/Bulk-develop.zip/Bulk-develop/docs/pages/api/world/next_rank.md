# `bulk::world::next_rank`

```cpp
int next_rank() const;
```

Returns the id of the next logical processor.

## Return value

- `int`: The id of the next processor
