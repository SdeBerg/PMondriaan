# `bulk::world::rank`

```cpp
int rank() const;
```

Returns the local processor id

## Return value

- `int`: The id of the local processor.
