# `bulk::coarray::slice`

Defined in header `<bulk/coarray.hpp>`.

```cpp
struct slice {
    int first;
    int last;
};
```
