#include <bulk/bulk.hpp>
#include <bulk/backends/thread/thread.hpp>
#include <hypergraph.hpp>
#include <readhypergraph.hpp>
#include <bisect.hpp>