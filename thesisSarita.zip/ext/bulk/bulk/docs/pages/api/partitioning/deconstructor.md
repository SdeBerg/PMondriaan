# `bulk::partitioning::~partitioning`

```cpp
virtual ~partitioning() = default;
```

Virtual deconstructor.
