# `bulk::rectangular_partitioning::~rectangular_partitioning`

```cpp
virtual ~rectangular_partitioning() = default;
```

Virtual deconstructor.
