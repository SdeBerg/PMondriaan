# `bulk::queue::queue`

```cpp
queue(world& world);
```

Constructs a message queue for use in `world`.

## Parameters

* `world` - the world this queue belongs to
