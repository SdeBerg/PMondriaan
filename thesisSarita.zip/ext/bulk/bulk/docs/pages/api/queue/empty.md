# `bulk::queue::empty`

```cpp
bool empty() const;
```

Checks whether the inbox is empty.

## Return value

- `true` if the inbox is empty, `false` otherwise.
