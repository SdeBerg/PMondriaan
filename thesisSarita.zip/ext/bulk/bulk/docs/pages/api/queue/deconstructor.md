# `bulk::queue::~queue`

```cpp
~queue();
```

Deconstructs a queue, clears and deregisters it.
