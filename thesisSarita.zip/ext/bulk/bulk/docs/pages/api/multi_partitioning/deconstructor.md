# `bulk::multi_partitioning::~multi_partitioning`

```cpp
virtual ~multi_partitioning() = default;
```

Virtual deconstructor.
