# Build the Bulk documentation

```bash
pip install --user mkdocs mkdocs-material
mkdocs gh-deploy
```
